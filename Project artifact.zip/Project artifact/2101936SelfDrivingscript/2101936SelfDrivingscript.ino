//initolising all the pins that the motor sheild uses
#define BRAKE 0
#define CW    1
#define CCW   2
#define CS_THRESHOLD 15   // Definition of safety current (Check: "1.3 Monster Shield Example").

//MOTOR 1
#define MOTOR_A1_PIN 7
#define MOTOR_B1_PIN 8

//MOTOR 2
#define MOTOR_A2_PIN 4
#define MOTOR_B2_PIN 9

#define PWM_MOTOR_1 5
#define PWM_MOTOR_2 6

#define CURRENT_SEN_1 A2
#define CURRENT_SEN_2 A3

#define EN_PIN_1 A0
#define EN_PIN_2 A1

#define MOTOR_1 0
#define MOTOR_2 1

int usSpeed = 60;  //motor speed
unsigned short usMotor_Status = BRAKE;

String message = ""; //decliring the message string that MQTT uses

//mqtt libary, Wi-Fi liabry, Led matrix libary
#include <ArduinoMqttClient.h>
#include <WiFiS3.h>
#include "Arduino_LED_Matrix.h"

//LED matrix values to show what stage the car is in for connections
const uint32_t danger[] = {
	0x400a015,
	0x1502082,
	0x484047fc
}; 

const uint32_t happy[] = {
	0x19819,
	0x80000001,
	0x81f8000
};

const uint32_t heart[] = {
	0x3184a444,
	0x44042081,
	0x100a0040
};

//declair the led matrix to allow changes
ArduinoLEDMatrix matrix; 

//Initialising wifi details
char ssid[] = "WemosCon";    // your network SSID (name)
char pass[] = "Inazuma14";    // your network password (use for WPA, or use as key for WEP)


//delairing wifi and mqtt connections
WiFiClient wifiClient;
MqttClient mqttClient(wifiClient);

//Initialising broker address and what port is used
const char broker[] = "100.26.180.249";
int        port     = 1883;

//Initialising what channel the broker will use
//const char topic[]  = "outTopic";
const char topic2[] = "test";
 
void setup()                         
{
   //start serial
   Serial.begin(9600);

  // attempt to connect to WiFi network:
  Serial.print("Attempting to connect to WPA SSID: ");
  Serial.println(ssid);
  //while not connected add a dot to the serial to show that its still trying
  while (WiFi.begin(ssid, pass) != WL_CONNECTED) {
    // failed, retry
    Serial.print(".");
    delay(1000);
  }
// print that the ardiuno is connected and shows a happy face 
  Serial.println("You're connected to the network");
  Serial.println();
  matrix.begin();  
  matrix.loadFrame(happy);

//displays what MQTT brocker we are trying to connect to 
  Serial.print("Attempting to connect to the MQTT broker: ");
  Serial.println(broker);

//if the arduino cant connect try say the error message
  if (!mqttClient.connect(broker, port)) {
    Serial.print("MQTT connection failed! Error code = ");
    Serial.println(mqttClient.connectError());
    while (1);
  }

//display a message saying you connected to the broker
  Serial.println("You're connected to the MQTT broker!");
  Serial.println();

//the indented code was for being able to connected to the rc car or sensor data
  //Serial.println("Enter mode (1 or 2): 1 allows rc control 2 will self drive if nether is pressed rc will be defualt");

  //while (!Serial.available());

  //char c = Serial.read();

  //if (c == '1') {


    //Serial.println("RC Mode  selected");

      //Serial.print("Subscribing to topic: ");
  //Serial.println(topic);
  //Serial.println();

  // subscribe to a topic
 // mqttClient.subscribe(topic);

  // topics can be unsubscribed using:
  // mqttClient.unsubscribe(topic);

  //Serial.print("Waiting for messages on topic: ");
 // Serial.println(topic);
  //Serial.println();



  //} else if (c == '2') {
  //Serial.println("Mode 2 selected self driving");
  //display what MQTT channel will be subscribed to 
  Serial.print("Subscribing to topic: ");
  Serial.println(topic2);
  Serial.println();

  // subscribe to a topic
  mqttClient.subscribe(topic2);

  // topics can be unsubscribed using:
  // mqttClient.unsubscribe(topic);
  
  //displays the chanel that is brocker is connected to 
  Serial.print("Waiting for messages on topic: ");
  Serial.println(topic2);
  Serial.println();

  //uses the led matrix to show that the car has connected to the broker and chanel
  matrix.loadFrame(heart);

  //} else {
    //Serial.println("Invalid input rc mode will be done now");

      //Serial.print("Subscribing to topic: ");
  //Serial.println(topic);
  //Serial.println();

  

  // subscribe to a topic
  //mqttClient.subscribe(topic2);

  // topics can be unsubscribed using:
  // mqttClient.unsubscribe(topic);

  Serial.print("Waiting for messages on topic: ");
  Serial.println(topic2);
  Serial.println();
  
  //gets the motor sheild ready to be used
  pinMode(MOTOR_A1_PIN, OUTPUT);
  pinMode(MOTOR_B1_PIN, OUTPUT);

  pinMode(MOTOR_A2_PIN, OUTPUT);
  pinMode(MOTOR_B2_PIN, OUTPUT);

  pinMode(PWM_MOTOR_1, OUTPUT);
  pinMode(PWM_MOTOR_2, OUTPUT);

  pinMode(CURRENT_SEN_1, OUTPUT);
  pinMode(CURRENT_SEN_2, OUTPUT);  

  pinMode(EN_PIN_1, OUTPUT);
  pinMode(EN_PIN_2, OUTPUT);


}


void loop() 
{   

//matrix.clear();

  //checks the server that a new message has come in
  int messageSize = mqttClient.parseMessage();
  
  //if the message size has any size then
  if (messageSize) {
    //makes the massage blank to then be filled
    message = "";
    // we received a message, print out the topic and contents
   // Serial.print("Received a message with topic '");
    //Serial.print(mqttClient.messageTopic());
    //Serial.print("', length ");
    //Serial.print(messageSize);
    //Serial.println(" bytes:");

    // use the Stream interface to print the contents
    while (mqttClient.available()) {
        // addes the value of the message to the blank string
        char c = (char)mqttClient.read();
        message += c;
    }
    //displayes what the message is and that new one has been recived
    Serial.print("OI HERE IS YOUR FULL MESSAGE");
    Serial.println(message);
    //int length = strlen(message);
    Serial.println();
    Serial.println();
  }



    digitalWrite(EN_PIN_1, HIGH);
    digitalWrite(EN_PIN_2, HIGH); 
      //resets the values of the sensor readings to be used again
      int frount=0, back=0, left=0, right =0;
      

      //Serial.println(temp); 
    //splits the message by comma and give the values into the corect direction that the sensor faces
    if (sscanf(message.c_str(), "%d,%d,%d,%d", &frount, &back, &left, &right) == 4) {
      //displays the value of the sensor and what direction its in
      Serial.println(frount);
      Serial.println(back);
      Serial.println(left);
      Serial.println(right);
    } 

    //if there is no object infrount of the car then it will go forward
    if(frount > 20){
        Forward();
    }   
    //if the car is surrounded then it will stop and go backwards
    else if(frount <=20 && left <= 20 && right<=20){
      Stop();     
      Reverse();
      delay(150);
      Stop();
      //Reverse();
      //delay(500);
      //Stop();
    }   
    //if the car has more space on the left it will trun that way
    else if (right < left && frount <=20){
      Left();
      Stop();
    }
    //if the car has more space on the right then it will turn that way
    else if ( left < right  && frount <=20 ){
      Right();
      Stop();
    }   
    //if the car has the frount or one of the sides has an object facing it then it will stop
    else if(frount <=20 && right<= 20 || frount <=20 && left <= 20){
      Stop();
    }
    //if no conditions are met then go forward
    else{
      Forward();
      
    }

}



void RC()
{
  //if message has that value it will stop
      if (message == "hello world #128")
    {
       Stop();
    }
    else if(message == "hello world #64")
    {
      //if message has that value it will go forward
      Forward();
    }
    else if(message == "hello world #1")
    {
      //if message has that value it will revese
      Reverse();
    }
    else if(message == "hello world #16")
    {
      Serial.print("test button");
    }
    else if("hello world #17")
    {//if message has that value it will slow down
      DecreaseSpeed();
    }
    else if( message == "hello world #32"){
      //if message has that value it will turn right
      Right();
    }
    else if(message == "hello world #2"){
      //if message has that value it will turn left
      Left();
    }
    else
    //it will say that there is an error in the terminal
    Serial.print("ERROR");
    
}

void Stop()
{
  //stop the car by making the wheel speed 0
  Serial.println("Stop");
  usMotor_Status = BRAKE;
  motorGo(MOTOR_1, usMotor_Status, 0);
  motorGo(MOTOR_2, usMotor_Status, 0);
  //delay(500);
  //will show that there is an object in the way with a haxzard sign
  matrix.loadFrame(danger);
}

void Forward()
{
  Serial.println("Forward");
  //make the wheels spin counter clockwise
  usMotor_Status = CCW;
  //make the moters spin at the speed said at the top which is the default speed
  motorGo(MOTOR_1, usMotor_Status, (usSpeed));
  motorGo(MOTOR_2, usMotor_Status, (usSpeed));
  matrix.clear();
}

void Left(){
  Serial.println("Left");
  //make the right motor turn clockwise and the left counter clockwise at the default speed
  motorGo(MOTOR_1, CW, usSpeed);
  motorGo(MOTOR_2, CCW, usSpeed);
  //make the car stop after a little bit to stop the car from turning forever
  delay(150);
  return;
}

void Right(){
  Serial.println("Right");
  //make the right motor spin counter clockwise and the left one spin clockwise at the default speed
  motorGo(MOTOR_1, CCW, usSpeed);
  motorGo(MOTOR_2, CW, usSpeed);
  //make the car stop to preven the car spinning forever
  delay(150);
  return;
}

void Reverse()
{
  Serial.println("Reverse");
  //make the cars wheels turn clockwise at the same speed
  usMotor_Status = CW;
  motorGo(MOTOR_1, usMotor_Status, usSpeed);
  motorGo(MOTOR_2, usMotor_Status, usSpeed);
}

void IncreaseSpeed()
{
  //adds the value 10 to the defualt speed to make the car go faster and have a top speed of 255
  usSpeed = usSpeed + 10;
  if(usSpeed > 255)
  {
    usSpeed = 255;  
  }
  
  //say what the spped is now 
  Serial.print("Speed +: ");
  Serial.println(usSpeed);

  //make the wheels speed up to the new speed
  motorGo(MOTOR_1, usMotor_Status, usSpeed);
  motorGo(MOTOR_2, usMotor_Status, usSpeed);  
}

void DecreaseSpeed()
{
  //subtracts the value 10 to the defualt speed to make the car go faster and have a lowest speed of 0
  usSpeed = usSpeed - 10;
  if(usSpeed < 0)
  {
    usSpeed = 0;  
  }

 //say what the new speed of the car will be 
  Serial.print("Speed -: ");
  Serial.println(usSpeed);
//make the car go the same way with now a lower speed
  motorGo(MOTOR_1, usMotor_Status, usSpeed);
  motorGo(MOTOR_2, usMotor_Status, usSpeed);  
}


void motorGo(uint8_t motor, uint8_t direct, uint8_t pwm)         //Function that controls the variables: motor(0 ou 1), direction (cw ou ccw) e pwm (entra 0 e 255);
{
  //start the logic for the first motor
  if(motor == MOTOR_1)
  { //if the instruction is to make the wheel spin clockwise then
    if(direct == CW)
    {
      //set motor A1 to off and B1 to on
      digitalWrite(MOTOR_A1_PIN, LOW); 
      digitalWrite(MOTOR_B1_PIN, HIGH);
    }
    //if the instruction is to turn the wheel counter clockwise
    else if(direct == CCW)
    {
      //set motor A1 on and B1 off
      digitalWrite(MOTOR_A1_PIN, HIGH);
      digitalWrite(MOTOR_B1_PIN, LOW);      
    }
    else
    {
      //otherwise set both motor pins to be off
      digitalWrite(MOTOR_A1_PIN, LOW);
      digitalWrite(MOTOR_B1_PIN, LOW);            
    }
    
    analogWrite(PWM_MOTOR_1, pwm); 
  }
  //if motor two is selected then
  else if(motor == MOTOR_2)
  {
    //if motor 2 is to turn clockwise
    if(direct == CW)
    {
      // set A2 on and B2 off
      digitalWrite(MOTOR_A2_PIN, HIGH);
      digitalWrite(MOTOR_B2_PIN, LOW);
    }
    //if the car wheel is to turn counter clockwise
    else if(direct == CCW)
    {
      //set A2 off and B2 on
      digitalWrite(MOTOR_A2_PIN, LOW);
      digitalWrite(MOTOR_B2_PIN, HIGH);      
    }
    else
    {
      //if the car is to stop then set both motor pins off
      digitalWrite(MOTOR_A2_PIN, LOW);
      digitalWrite(MOTOR_B2_PIN, LOW);            
    }
    
    analogWrite(PWM_MOTOR_2, pwm);
  }

}


  

