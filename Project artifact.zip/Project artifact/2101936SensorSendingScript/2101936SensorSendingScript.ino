//Declairing libary use
#ifdef ESP8266
#include <ESP8266WiFi.h>
#elif defined(ESP32)
#include <WiFi.h>
#include <esp_random.h>
#define BUILTIN_LED A0
#define RANDOM_REG32 esp_random()
#else
#error Platform not supported.
#endif
#include <PubSubClient.h>

/*
Declairing all nessasery parts for the remote controll to work

#include <TM1638plus.h> //include the library
#define STROBE_TM D5 // strobe = GPIO connected to strobe line of module
#define CLOCK_TM D6 // clock = GPIO connected to clock line of module
#define DIO_TM D7 // data = GPIO connected to data line of module
bool high_freq = false; //default false, If using a high freq CPU > ~100 MHZ set to true.
// Constructor object (GPIO STB , GPIO CLOCK , GPIO DIO, use high freq MCU)
TM1638plus tm(STROBE_TM, CLOCK_TM , DIO_TM, high_freq);
byte buttons;
*/


// Values to connect to wifi and IP address of MQTT address

const char* ssid = "WemosCon";
const char* password = "Inazuma14";
const char* mqtt_server = "100.26.180.249";

//Declairing the sensors redings to be changed when they arrive

int F_Sensor = 1;
int L_Sensor = 2;
int R_Sensor = 3;
int B_Sensor = 4;

//Declairing all the pins that the sensors use

#define F_echo_pin D7   
#define F_trig_pin D6   

#define B_echo_pin D5    
#define B_trig_pin D8    

#define R_echo_pin D1
#define R_trig_pin D0

#define L_echo_pin D2
#define L_trig_pin D3

//Declairing the values for the MQTT labiers

WiFiClient espClient;
PubSubClient client(espClient);
unsigned long lastMsg = 0;

//Declairing the size of 
#define MSG_BUFFER_SIZE	(50)
char msg[MSG_BUFFER_SIZE];
char Bmsg[MSG_BUFFER_SIZE];

//RC value that worked with tthe seven segment display
int value = 0;


void setup_wifi() {
    delay(10);
    //  start  connecting to a WiFi network with the details above
    Serial.println();
    Serial.print("Connecting to ");
    Serial.println(ssid);

    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);

    //while you are not connected a dot will appear in the terminal
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    randomSeed(RANDOM_REG32);
    // Once connected your IP address will apear as well as a small message saying that you connected
    Serial.println("");
    Serial.println("WiFi connected");
    Serial.println("IP address: ");
    Serial.println(WiFi.localIP());
    
}


void reconnect() {
    // Loop until we're reconnected
    while (!client.connected()) {
        Serial.print("Attempting MQTT connection...");
        // Create a random client ID
        String clientId = "ESP8266Client-";
        clientId += String(random(0xffff), HEX);
        // Attempt to connect
        if (client.connect(clientId.c_str())) {
            Serial.println("connected");
            // Once connected, publish an announcement...
            client.publish("outTopic", "hello world");
            // ... and resubscribe
            client.subscribe("inTopic");
        } else {
            Serial.print("failed, rc=");
            Serial.print(client.state());
            Serial.println(" try again in 5 seconds");
            // Wait 5 seconds before retrying
            
        }
    }
}

void setup() {
    // Initialize the BUILTIN_LED pin as an output
    pinMode(BUILTIN_LED, OUTPUT);  
    //Initialize all the ultrasonic senssors
    pinMode(F_echo_pin, INPUT);
    pinMode(F_trig_pin, OUTPUT);
    pinMode(B_echo_pin, INPUT);
    pinMode(B_trig_pin, OUTPUT);
    pinMode(R_echo_pin, INPUT);
    pinMode(R_trig_pin, OUTPUT);
    pinMode(L_echo_pin, INPUT);
    pinMode(L_trig_pin, OUTPUT);

    //delair waht serial is being used
    Serial.begin(115200);
    //Call the wifi function to connect to wifi
    setup_wifi();
    //ONce connected to wifi connect to the mqtt server
    client.setServer(mqtt_server, 1883);
    reconnect();
    //client.setCallback(callback);
    //code to get the seven segment display working and ready to control the car
    //tm.displayBegin();
 //tm.reset();
// set up a pattern on the LEDs
 //tm.setLEDs(0x0100); //The MSB of this 16 bit value controls which LEDS light up
}

void loop() {
    
    if (!client.connected()) {
        reconnect();
    }
    client.loop();
    
    // call the sensors function to get a reading to be sent over MQTT
   int F_Sensor = Distance(F_trig_pin, F_echo_pin);
   delay(60);
   int B_Sensor = Distance(B_trig_pin, B_echo_pin);
   delay(60);
   //Serial.print(B_Sensor);
   int R_Sensor = Distance(R_trig_pin, R_echo_pin);
   delay(60);
   //Serial.print(R_Sensor);
   int L_Sensor = Distance(L_trig_pin, L_echo_pin);
   delay (60);
   //Serial.print(L_Sensor);

    //Start a timer to be able to track when the last message was sent
    unsigned long now = millis();
    //If the last message sent was in the last 50 milliseconds it wont send 
    if (now - lastMsg > 50) {
        //reset the timer
        lastMsg = now;
        // buttons = tm.readButtons(); // read which buttons are pressed
        //tm.displayIntNum(buttons);
        
        //This says what is going to be sent in the serial monitor
        Serial.print("Publish message: ");
        Serial.println(Bmsg);

         //The message that would be sent to the car if RC function is wanting to be used on the right channel
         //snprintf(msg, MSG_BUFFER_SIZE, "hello world #%d", buttons);

        //The messgae data for the four sensor readings to be sent over MQTT server split by ,
         snprintf(Bmsg, MSG_BUFFER_SIZE, "%d,%d,%d,%d", F_Sensor, B_Sensor, L_Sensor,R_Sensor );
        
        //client.publish("outTopic", msg);
        client.publish("test", Bmsg);
    }


}

//distance function to use the sensor
int Distance(uint8_t trigPin,uint8_t echoPin){
  //makes sure that the trig pin is not active
  digitalWrite(trigPin, LOW);
  delayMicroseconds(20);
  //sets the trig pin on to send a soundwave
  digitalWrite(trigPin, HIGH);
  //waits for 10 microseconds before switching the pinn off stoping the wave
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  delayMicroseconds(10);
  pinMode(echoPin, INPUT);
  //starts the timer to calculate distance
  int duration = pulseIn(echoPin, HIGH);
  // Convert the time into a distance cut in half to get the hlaf the time since the full time is getting the signal and back
  int cm = (duration/2) / 29.1;
  //Serial.println(cm);
  //Serial.println("...   and time was -");
  //Serial.println(duration);
  //return the distance an object is in cm
  return cm;

}